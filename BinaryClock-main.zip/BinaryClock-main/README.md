Building a binary clock using an ATmega48a and a custom pcb

TODO:

- [ ] Brightness levels are inverted

- [ ] mcu doesnt get back to sleep