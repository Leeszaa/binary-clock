#define F_CPU 1000000UL

#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/sleep.h>
#include <util/delay.h>

#define BUTTON_BRIGHTNESS PD2
#define BUTTON_WAKE PD3

//LEDs for hours
#define HOURS_DDR DDRD
#define HOURS_PORT PORTD
#define HOURS_MASK 0xf1

//LEDs for minutes
#define MINUTES_DDR DDRC
#define MINUTES_PORT PORTC
#define MINUTES_MASK 0x3f

//PWM output
#define HOURS_PWM  PB1
#define MINUTES_PWM PB2

//Brightness level in 20% increments
#define NUM_BRIGHTNESS_LEVELS 5
volatile uint8_t brightnessLevelIndex = 0;
const uint8_t brightnessValues[NUM_BRIGHTNESS_LEVELS] = {
  51,
  102,
  153,
  204,
  255
};

//Timer2 keeping track of time
volatile uint8_t seconds = 0;
volatile uint8_t minutes = 0;
volatile uint8_t hours = 0;

//debouncing buttons
#define DEBOUNCE_DELAY_MS 50

//Sleepmode tracker + reenter sleepmode time
volatile uint32_t millis10 = 0;
volatile uint16_t wakeTime = 0;
volatile uint8_t  isAwake  = 0;
#define WAKE_TIMEOUT_TICKS 1000

//part of button ISR
volatile uint32_t lastInt0Time = 0;  // last time we accepted INT0 (brightness btn)
volatile uint32_t lastInt1Time = 0;  // last time we accepted INT1 (wake btn)

//Prototypes
void initIO(void);
void initTimer0_10ms(void);
void initTimer1PWM(void);
void initTimer2Async(void);

void displayTime(uint8_t h, uint8_t m);
void clearTimeDisplay(void);
void displayBrightnessLevel(uint8_t level);

int main(void) {
  initIO();
  initTimer0_10ms();
  initTimer1PWM();
  initTimer2Async();
  sei();
  set_sleep_mode(SLEEP_MODE_PWR_SAVE);

  EICRA |= (1 << ISC10) | (1 << ISC11);
  EIMSK |= (1 << INT0) | (1 << INT1);

  isAwake = 0;

  while(1) {
    if(isAwake) {
      displayTime(hours, minutes);
    }
    else {
      clearTimeDisplay();

      sleep_enable();
      sleep_cpu();
      sleep_disable();
    }
  }
}

void initIO(void) {
  //Buttons as input with internal pull up
  DDRD &= ~((1 << BUTTON_BRIGHTNESS) | (1 << BUTTON_WAKE));
  PORTD |= (1 << BUTTON_BRIGHTNESS) | (1 << BUTTON_WAKE);

  //hours as outputs
  HOURS_DDR |= HOURS_MASK;
  HOURS_PORT &= ~HOURS_MASK;

  //minutes as outputs
  MINUTES_DDR |= MINUTES_MASK;
  MINUTES_PORT &= ~MINUTES_MASK;

  //pwm pins as outputs
  DDRB |= (1 << HOURS_PWM) | (1 << MINUTES_PWM);
}

//Timer0 for debouncing buttons and automativally reentering sleepmode after 10 seconds
void initTimer0_10ms(void) {
  TCCR0A = (1 << WGM01);
  TCCR0B = (1 << CS02) | (1 << CS00);
  OCR0A = 155;
  TIMSK0 = (1 << OCIE0A);
}

ISR(TIMER0_COMPA_vect) {
  millis10 += 10;

  if(isAwake) {
    wakeTime++;
    if(wakeTime >= WAKE_TIMEOUT_TICKS) {
      isAwake = 0;
    }
  }
}

//Timer1 for PWM
void initTimer1PWM(void) {
  TCCR1A = (1 << WGM10) | (1 << COM1A1) | (1 << COM1B1);
  TCCR1B = (1 << WGM12) | (1 << CS11);

  OCR1A = brightnessValues[brightnessLevelIndex];
  OCR1B = brightnessValues[brightnessLevelIndex];
}

//Timer2 for keeping track of time
void initTimer2Async(void) {
  ASSR = (1 << AS2);
  TCCR2B = (1 << CS22) | (1 << CS20);
  TIMSK2 = (1 << TOIE2);

  while(ASSR & ((1 << TCR2BUB) | (1 << TCN2UB) | (1 << OCR2AUB))) {
    //wait
    }
}

ISR(TIMER2_OVF_vect) {
  seconds++;

  if(seconds >= 60) {
    seconds = 0;
    minutes++;
    if(minutes >= 60) {
      minutes = 0;
      hours++;
      if(hours >= 24) {
        hours = 0;
      }
    }
  }
}

//Brightness change button ISR
ISR(INT0_vect) {
  uint32_t now = millis10;

  if((now - lastInt0Time) >= DEBOUNCE_DELAY_MS) {
    lastInt0Time = now;
    brightnessLevelIndex++;
    if(brightnessLevelIndex >= NUM_BRIGHTNESS_LEVELS) {
      brightnessLevelIndex = 0;
    }

    OCR1A = brightnessValues[brightnessLevelIndex];
    OCR1B = brightnessValues[brightnessLevelIndex];

    displayBrightnessLevel(brightnessLevelIndex + 1);

    isAwake = 1;
    wakeTime = 0;
  }
}

//Wake button ISR
ISR(INT1_vect) {
  isAwake = 1;
  wakeTime = 0;
  /*uint32_t now = millis10;

  if((now - lastInt1Time) >= DEBOUNCE_DELAY_MS) {
    lastInt1Time = now;
    isAwake = 1;
    wakeTime = 0;
  }*/
}

//show current brightness level on hour LEDs
void displayBrightnessLevel(uint8_t level) {
  uint8_t levelMask = 0;
  static const uint8_t hourLedPins[5] = {PD7, PD6, PD5, PD4, PD0};

  for (uint8_t i = 0; i < level && i < 5; i++) {
    levelMask |= (1 << hourLedPins[i]);
  }

  HOURS_PORT = (HOURS_PORT & ~HOURS_MASK) | (levelMask & HOURS_MASK);
  _delay_ms(300);

  HOURS_PORT &= ~HOURS_MASK;
}

void displayTime(uint8_t h, uint8_t m) {
  uint8_t hmask = 0;
  if (h & (1 << 4)) hmask |= (1 << PD7);
  if (h & (1 << 3)) hmask |= (1 << PD6);
  if (h & (1 << 2)) hmask |= (1 << PD5);
  if (h & (1 << 1)) hmask |= (1 << PD4);
  if (h & (1 << 0)) hmask |= (1 << PD0);

  PORTD = (PORTD & ~HOURS_MASK) | (hmask & HOURS_MASK);

  PORTC = (PORTC & ~MINUTES_MASK) | (m & 0x3F);
}

void clearTimeDisplay(void) {
  HOURS_PORT &= ~HOURS_MASK;
  MINUTES_PORT &= ~MINUTES_MASK;
}